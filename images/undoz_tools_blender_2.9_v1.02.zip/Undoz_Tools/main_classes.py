import bpy
import math
from . import functions as fu


# Classes             
####################################################

     
class UNDOZ_OT_PivotAlign(bpy.types.Operator):
    "Aligns the Origin pivot to the active selection"
    bl_idname = "undoz.pivot_align"
    bl_label = "undoz: Align Origin Pivot To Selection"
    bl_description = "Aligns the Origin pivot to the active selection"
    bl_options = {'REGISTER', 'UNDO'} 

    def execute(self, context):
        obj = bpy.context.active_object
        selection_active = bpy.context.active_object
        selection = bpy.context.selected_objects
        mode = ""
        
        # determine if mode of operation is object 
        if bpy.context.object.mode == 'OBJECT':
            print ("object mode")
            # are there multiple objects selected ?

            if len(selection) <= 1:
                self.report({'WARNING'}, "There is nothing to align the object to")
                return {'FINISHED'} # exit because there is nothing to align to 
            
            # multiple objects detected
            else:
                
                for ob in selection: # find the non active object to be aling to the active
                    
                    if ob != selection_active: # determine that object is not the same as active
                        obj = ob
                        print("\nAligning {}'s pivot to {}\n".format(obj.name, selection_active.name))
                        break # object found, now exit

                    else:
                        print ("Selection not found?!")

                mode = "OBJECT"

        elif bpy.context.object.mode == 'EDIT':

            # check if subselection is valid and if any vertices are selected
            if obj.data.vertices.data.count_selected_items()[0] < 1: 
                self.report({'WARNING'}, "Nothing is selected")
                return {'FINISHED'} # exit: no selection has been made
                
        else:
            self.report({'WARNING'}, "Object mode is not valid. Please switch to Object or Edit mode")
            return {'FINISHED'} # exit: no valid mode

        # get current orientation by creating a custom orientation 
        bpy.ops.transform.create_orientation(name="tempOrient", use=True, overwrite=True)
        bpy.ops.transform.select_orientation(orientation="tempOrient")
        orientVal = bpy.data.scenes[0].transform_orientation_slots[0].custom_orientation.matrix.to_euler()
        bpy.ops.transform.delete_orientation() 

        #get location 
        if mode == "OBJECT":
            translateVal = selection_active.location
        else:
            bpy.ops.view3d.snap_cursor_to_selected()
            translateVal = bpy.context.scene.cursor.location

        # run the origin pivot set function
        fu.set_origin(obj, orientVal, translateVal)

        return {'FINISHED'}

class UNDOZ_OT_Utest(bpy.types.Operator):
    "Test Script"
    bl_idname = "undoz.utest"
    bl_label = "undoz: Test script"

    def execute(self, context):
        Print("Test")

        return {'FINISHED'}