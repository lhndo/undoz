import bpy


# Functions
####################################################


def set_origin(obj, orientValue, translateVal):

    # set state
    bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
    bpy.ops.object.select_all(action='DESELECT')
    
    # add empty
    bpy.ops.object.empty_add(type='PLAIN_AXES')
    empty = bpy.context.active_object

    # create rotation reference
    empty.rotation_euler = orientValue
    bpy.ops.transform.create_orientation(name="rot", use=True, overwrite=True)

    # create negative rotation reference
    empty.rotation_euler = orientValue.to_matrix().inverted().to_euler()
    bpy.ops.transform.create_orientation(name="rotNeg", use=True, overwrite=True)

    # cleanup empty
    bpy.ops.object.delete()
    bpy.ops.object.select_all(action='DESELECT')

    # start orienting the object and pivot
    obj.select_set(state=True)
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)
    bpy.ops.transform.transform(mode='ALIGN', value=(0, 0, 0, 0), constraint_axis=(False, False, False), 
                                orient_type='rotNeg', mirror=False)
    
    # reset pivot before final translation
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)

    bpy.ops.transform.transform(mode='ALIGN', value=(0, 0, 0, 0), constraint_axis=(False, False, False), 
                                orient_type='rot', mirror=False)

    # assign pivot location   
    bpy.context.scene.cursor.location = translateVal
    bpy.ops.object.origin_set(type='ORIGIN_CURSOR')                            

    # cleanup
    bpy.ops.transform.select_orientation(orientation='rot')
    bpy.ops.transform.delete_orientation() 
    bpy.ops.transform.select_orientation(orientation='rotNeg')
    bpy.ops.transform.delete_orientation() 
    bpy.ops.transform.select_orientation(orientation='LOCAL')
    bpy.context.view_layer.objects.active = obj
    bpy.ops.wm.tool_set_by_id(name="builtin.rotate") #set rotate tool 

    return True
