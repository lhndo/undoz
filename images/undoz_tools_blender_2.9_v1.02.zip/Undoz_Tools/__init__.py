'''
Copyright (C) 2015-2019 Andrei Cristea All Rights Reserved

 This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.

by: Andrei Cristea - www.undoz.com

'''

bl_info = {
    "name" : "Undoz Tools",
    'description': 'Align Origin Pivot To Selection',
    "author" : "Andrei Cristea",
    "version" : (0, 0, 2),
    "blender" : (2, 90, 0),
    'location': 'View3D',
    'wiki_url': 'https://www.undoz.com/blog',
    "category" : "3D View", }



if "bpy" in locals():
    import importlib
    
    importlib.reload(main_classes)    
    importlib.reload(functions)
    
else:
    from .main_classes import *
    from .functions import *
    
    
import bpy
import bgl
import blf    
    

classes = (
    main_classes.UNDOZ_OT_PivotAlign,
#    main_classes.UNDOZ_OT_Utest
)

def menu_VIEW3D_MT_undoz_tools(self, context):
    layout = self.layout
    layout.separator()
    layout.operator("undoz.pivot_align", text="Align Origin To Selection")
    



def register():
    from bpy.utils import register_class
    
    for cls in classes:
        register_class(cls)
        
    bpy.types.VIEW3D_MT_object_context_menu.append(menu_VIEW3D_MT_undoz_tools)
    bpy.types.VIEW3D_MT_edit_mesh_context_menu.append(menu_VIEW3D_MT_undoz_tools)
        

def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)
        
    bpy.types.VIEW3D_MT_object_context_menu.remove(menu_VIEW3D_MT_undoz_tools)
    bpy.types.VIEW3D_MT_edit_mesh_context_menu.remove(menu_VIEW3D_MT_undoz_tools)
        

if __name__ == "__main__":
    register()